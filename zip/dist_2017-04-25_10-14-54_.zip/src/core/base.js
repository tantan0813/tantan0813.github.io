class Base {
    basetest() {
        console.log(1111);
    }
}
export default Base;

