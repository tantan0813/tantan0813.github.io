---
layout: home
---
<div class="bg-music" id="music">
  <a class="mscBtn play" id="audioBtn" style="cursor:pointer;"></a>
  <audio id="bgMusic" src="" autoplay="autoplay" loop="loop"></audio>
</div>
<div class="index-content life">
  <div class="section">
    <ul class="artical-cate">
      <li><a href="/coding"><span>程序人生</span></a></li>
      <li class="on" style="text-align:center"><a href="/life"><span>心情杂记</span></a></li>
      <li style="text-align:center"><a href="/project"><span>项目历练</span></a></li>
    </ul>

    <div class="cate-bar"><span id="cateBar"></span></div>

    <div id="play_01">
    <div class="wrapper progress"><!-- 容器 -->
                    <div class="littleH"><!-- 小黄人 -->
                        <div class="bodyH"><!-- 身体 -->
                            <div class="trousers"><!-- 裤子 -->
                                <div class="condoleBelt"><!-- 吊带 -->
                                    <div class="left"></div>
                                    <div class="right"></div>
                                </div>
                                <div class="trousers_top"></div><!-- 裤子突出的矩形部分 -->
                                <div class="pocket"></div><!-- 裤袋 -->
                                <!-- 三条线 -->
                                <span class="line_left"></span>
                                <span class="line_right"></span>
                                <span class="line_bottom"></span>
                            </div>
                        </div>
                        <div class="hair"><!-- 头发 -->
                            <span class="left_hair_one"></span>
                            <span class="left_hair_two"></span>
                        </div>
                        <div class="eyes"><!-- 眼睛 -->
                            <div class="leftEye"><!-- 左眼 -->
                                <div class="left_blackEye">
                                    <div class="left_white"></div>
                                </div>
                            </div>
                            <div class="rightEye"><!-- 右眼 -->
                                <div class="right_blackEye">
                                    <div class="right_white"></div>
                                </div>
                            </div>
                        </div>
                        <div class="mouse"><!-- 嘴巴 -->
                            <div class="mouse_shape"></div>
                        </div>
                        <div class="hands"><!-- 双手 -->
                            <div class="leftHand"></div>
                            <div class="rightHand"></div>
                        </div>
                        <div class="feet"><!-- 双脚 -->
                            <div class="left_foot"></div>
                            <div class="right_foot"></div>
                        </div>
                        <div class="groundShadow"></div><!-- 脚底阴影 -->
                    </div>
    </div>
        <div id="art-page-all" style="display: none">
            <ul class="artical-list list-art">
                 {% for post in site.categories.life %}
                 <li class="list" style="display: none">
                        <div class="table-article">
                            <div class="col-title">
                                <h2><a href="{{ post.url }}">{{ post.title }}</a></h2>
                            </div>
                            <div class="col-date">
                                <p class="entry-date">{{ post.date|date:"%Y-%m-%d" }}</p>
                            </div>
                        </div>
                        <div class="title-desc">{{ post.description }}</div>
                 </li>
                 {% endfor %}
            </ul>
        </div>
   </div>


  </div>
  <div class="aside">
  </div>
</div>
